package com.jobportal.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayApplication {

    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(ApiGatewayApplication.class, args);
        System.out.println("API Gateway started on port 8085!");
        
        
    }
}